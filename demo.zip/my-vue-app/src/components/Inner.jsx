
export default {
  name: 'Inner',
  props: {
    data: {
      type: String,
    },
    loading: {
      type: Boolean
    }
  },
  render() {
    console.log('Inner', this.loading, this.data)
    return (
      <div>
        {/* "Inner"<br/> */}
        {this.loading && <div>'加载中...'</div>}
        {!this.loading && <div>{this.data}</div>}
      </div>
    )
  }
}
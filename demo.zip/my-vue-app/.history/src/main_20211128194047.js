import { createApp } from 'vue'
import App from './App.jsx'

createApp(App).mount('#app')

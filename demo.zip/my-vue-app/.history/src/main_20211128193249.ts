import { createApp } from 'vue'
import App from './App.tes'

createApp(App).mount('#app')

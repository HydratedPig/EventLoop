
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup
import Loading from './components/Loading'
export default {
  render() {
    return (
      <div>
        <img alt="Vue logo"/>
        test
        <Loading />
      </div>
    )
  }
}
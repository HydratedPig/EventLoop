
export default {
  name: 'Other',
  props: {
    data: {
      type: String,
    },
    loading: {
      type: Boolean
    }
  },
  render() {
    console.log('1', this.loading, this.data)
    return (
      <div>
      {this.loading && <div>'加载中...'</div>}
      {!this.loading && <div>{this.data}</div>}
    </div>
    )
  }
}
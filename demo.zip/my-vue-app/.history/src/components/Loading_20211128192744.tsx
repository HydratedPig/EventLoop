import { ref, onMounted, defineComponent } from 'vue'
import Other from './other.jsx'
function fetchData() {
  return new Promise(resolve => 
    setTimeout(() => {
      resolve({
        text: '这是返回的文本'
      })
    }, 2000)
  )
}

export default defineComponent({
  components: {
    Other
  },
  setup() {
    const loading = ref(false);
    const innerText = ref();

    const init = async () => {
      const { text } = await fetchData();
      innerText.value = text;
      // loading.value = false;
    }
    const wrap = async () => {
      await init()
    }

    onMounted(async () => {
      loading.value = true;
      await init();
      loading.value = false;
    })

    return {
      loading,
      innerText
    }
  },
  render() {
    return (
      <div style="width: 100px; height: 100px">
        <Other loading={this.loading} data={this.innerText}/>
      </div>
    )
  }
})
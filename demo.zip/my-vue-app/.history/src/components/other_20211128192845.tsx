import { defineComponent } from 'vue';
export default defineComponent({
  name: 'Other',
  props: {
    data: {
      type: String,
    },
    loading: {
      type: Boolean
    }
  },
  render() {
    return (
      <div>
      {this.loading && <div>'加载中...'</div>}
      {!this.loading && <div v-else>{this.data}</div>}
    </div>
    )
  }
})
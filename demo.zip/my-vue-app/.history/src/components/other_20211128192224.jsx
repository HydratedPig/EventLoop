<template>
  <div style="width: 100%;height: 100%">
    <div v-if="loading">'加载中...'</div>
    <div v-else>{{data}}</div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
export default defineComponent({
  name: 'Other',
  props: {
    data: {
      type: String,
    },
    loading: {
      type: Boolean
    }
  }
})
</script>

<style>

</style>
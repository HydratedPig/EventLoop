<template>
  <div style="width: 100px; height: 100px">
    <Other :loading="loading" :data="innerText"/>
  </div>
</template>
<script>
import { ref, onMounted, defineComponent } from 'vue'
import Other from './other.vue'
function fetchData(): Promise<{ text: string }> {
  return new Promise(resolve => 
    setTimeout(() => {
      resolve({
        text: '这是返回的文本'
      })
    }, 2000)
  )
}

export default defineComponent({
  components: {
    Other
  },
  setup() {
    const loading = ref(false);
    const innerText = ref();

    const init = async () => {
      const { text } = await fetchData();
      innerText.value = text;
      // loading.value = false;
    }
    const wrap = async () => {
      await init()
    }

    onMounted(async () => {
      loading.value = true;
      await wrap();
      loading.value = false;
    })

    return {
      loading,
      innerText
    }
  },
})
</script>


<script lang="ts" setup>


</script>

<style>

</style>
import { ref, onMounted, defineComponent } from 'vue'
import Other from './other'
function fetchData() {
  return new Promise(resolve => 
    setTimeout(() => {
      resolve({
        text: '这是返回的文本'
      })
    }, 2000)
  )
}

export default {
  setup() {
    const loading = ref(false);
    const innerText = ref();

    const init = async () => {
      const { text } = await fetchData();
      innerText.value = text;
      // loading.value = false;
    }

    onMounted(async () => {
      loading.value = true;
      await init();
      loading.value = false;
    })

    return {
      loading,
      innerText
    }
  },
  render() {
    console.log(0, this.loading, this.innerText)
    return (
      <div>
        <Other loading={this.loading} data={this.innerText}/>
      </div>
    )
  }
}